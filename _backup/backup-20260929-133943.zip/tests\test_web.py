"""网页控制台服务测试：用 aiohttp 自带的测试服务器，不占用真实端口。"""

from __future__ import annotations

import asyncio
import json

from aiohttp.test_utils import TestClient, TestServer

from cjsolver.config import load_config
from cjsolver.web.runtime import ConsoleRuntime
from cjsolver.web.server import create_app


async def with_client(tmp_dir: object, action: object) -> object:
    """起一个临时服务，执行 action(client)，最后关闭。"""
    config = load_config(project_root=tmp_dir)  # type: ignore[arg-type]
    runtime = ConsoleRuntime(config)
    await runtime.start()
    client = TestClient(TestServer(create_app(runtime)))
    await client.start_server()
    try:
        return await action(client)  # type: ignore[operator]
    finally:
        await client.close()
        await runtime.close()


def run(tmp_dir: object, action: object) -> object:
    return asyncio.run(with_client(tmp_dir, action))  # type: ignore[arg-type]


# --------------------------------------------------------------------------- #
# 页面与状态
# --------------------------------------------------------------------------- #
def test_index_page_is_served_with_utf8(tmp_dir: object) -> None:
    async def action(client: TestClient) -> tuple[int, str, str]:
        response = await client.get("/")
        body = await response.text()
        return response.status, response.headers.get("Content-Type", ""), body

    status, content_type, body = run(tmp_dir, action)
    assert status == 200
    assert "utf-8" in content_type.lower()
    assert "本地控制台" in body
    assert "EventSource" in body
    assert "/api/simulate" in body


def test_state_endpoint(tmp_dir: object) -> None:
    async def action(client: TestClient) -> dict:
        response = await client.get("/api/state")
        assert response.status == 200
        return await response.json()

    state = run(tmp_dir, action)
    assert state["site"]["key"] == "changjiang"
    assert state["answer"]["mode"] == "manual"
    assert state["model"]["configured"] is False   # 测试环境下没有 Key
    assert state["browser"]["attached"] is False
    assert state["watching"] is False
    assert state["stats"] is None
    assert state["last_simulation"] is None


def test_probe_endpoint(tmp_dir: object) -> None:
    async def action(client: TestClient) -> dict:
        response = await client.get("/api/probe")
        return await response.json()

    probe = run(tmp_dir, action)
    assert probe["api_key_configured"] is False
    assert probe["cdp_url"].startswith("http://127.0.0.1:")
    assert isinstance(probe["cdp_ready"], bool)


# --------------------------------------------------------------------------- #
# 模拟检测
# --------------------------------------------------------------------------- #
def test_simulate_offline_endpoint(tmp_dir: object) -> None:
    async def action(client: TestClient) -> dict:
        response = await client.post("/api/simulate", json={"kind": "offline"})
        assert response.status == 200, await response.text()
        return await response.json()

    payload = run(tmp_dir, action)
    assert payload["ok"] is True
    assert payload["report"]["ok"] is True
    keys = [check["key"] for check in payload["report"]["checks"]]
    assert "capture.presentation" in keys
    assert "answer.format" in keys
    # 没有 Key，模型项应当被跳过而不是判失败
    model = next(c for c in payload["report"]["checks"] if c["key"] == "model.deepseek")
    assert model["skipped"] is True and model["passed"] is True


def test_simulate_unknown_kind_returns_400(tmp_dir: object) -> None:
    async def action(client: TestClient) -> tuple[int, dict]:
        response = await client.post("/api/simulate", json={"kind": "nope"})
        return response.status, await response.json()

    status, payload = run(tmp_dir, action)
    assert status == 400
    assert payload["ok"] is False
    assert "未知的模拟类型" in payload["error"]


def test_simulate_live_without_watcher_returns_400(tmp_dir: object) -> None:
    async def action(client: TestClient) -> tuple[int, dict]:
        response = await client.post("/api/simulate", json={"kind": "live"})
        return response.status, await response.json()

    status, payload = run(tmp_dir, action)
    assert status == 400
    assert "先启动监听" in payload["error"]


def test_last_simulation_is_remembered_in_state(tmp_dir: object) -> None:
    async def action(client: TestClient) -> dict:
        await client.post("/api/simulate", json={"kind": "offline"})
        response = await client.get("/api/state")
        return await response.json()

    state = run(tmp_dir, action)
    assert state["last_simulation"]["ok"] is True


# --------------------------------------------------------------------------- #
# 其它接口
# --------------------------------------------------------------------------- #
def test_ask_without_api_key_is_rejected(tmp_dir: object) -> None:
    async def action(client: TestClient) -> tuple[int, dict]:
        response = await client.post("/api/ask", json={"text": "单选 1+1=?\nA. 1\nB. 2"})
        return response.status, await response.json()

    status, payload = run(tmp_dir, action)
    assert status == 400
    assert "API Key" in payload["error"]


def test_ask_with_empty_text_is_rejected(tmp_dir: object) -> None:
    async def action(client: TestClient) -> int:
        response = await client.post("/api/ask", json={"text": "   "})
        return response.status

    assert run(tmp_dir, action) == 400


def test_watch_start_without_api_key_is_rejected(tmp_dir: object) -> None:
    async def action(client: TestClient) -> tuple[int, dict]:
        response = await client.post("/api/watch/start", json={"mode": "manual"})
        return response.status, await response.json()

    status, payload = run(tmp_dir, action)
    # 没有 Key 时应当明确报错，而不是尝试启动会话
    assert status == 400
    assert payload["ok"] is False


def test_watch_stop_is_idempotent(tmp_dir: object) -> None:
    async def action(client: TestClient) -> bool:
        response = await client.post("/api/watch/stop", json={})
        payload = await response.json()
        return payload["ok"]

    assert run(tmp_dir, action) is True


def test_events_json_endpoint(tmp_dir: object) -> None:
    async def action(client: TestClient) -> dict:
        await client.post("/api/simulate", json={"kind": "offline"})
        response = await client.get("/api/events.json?limit=100")
        return await response.json()

    payload = run(tmp_dir, action)
    types = [event["type"] for event in payload["events"]]
    assert "simulation" in types
    assert "sim-log" in types


def test_sse_stream_sends_hello_frame(tmp_dir: object) -> None:
    captured: list[dict] = []

    async def action(client: TestClient) -> None:
        response = await client.get("/api/events")
        assert response.status == 200
        assert "text/event-stream" in response.headers["Content-Type"]
        try:
            # 单次 read 可能把一帧截断，这里累积到出现空行为止
            buffer = ""
            while "\n\n" not in buffer:
                chunk = await asyncio.wait_for(response.content.read(1024), timeout=5)
                if not chunk:
                    break
                buffer += chunk.decode("utf-8", errors="replace")
            frame = buffer.split("\n\n", 1)[0]
            assert frame.startswith("data: ")
            captured.append(json.loads(frame[len("data: "):]))
        finally:
            response.close()

    run(tmp_dir, action)
    assert captured, "SSE 应当立刻推送第一帧"
    event = captured[0]
    # hello 是服务端合成的一帧（不走总线，因此没有 seq），用来让新页面立刻拿到状态
    assert event["type"] == "hello"
    assert event["data"]["site"]["key"] == "changjiang"
    assert event["data"]["watching"] is False


def test_unknown_route_returns_404(tmp_dir: object) -> None:
    async def action(client: TestClient) -> int:
        response = await client.get("/api/nope")
        return response.status

    assert run(tmp_dir, action) == 404
