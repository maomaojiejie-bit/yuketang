"""控制台运行时：持有浏览器、模型客户端与监听会话的生命周期。

所有耗时操作都在同一个事件循环里，对外暴露的方法都可以被 HTTP 处理器直接 await。
"""

from __future__ import annotations

import asyncio
import dataclasses
import logging
from typing import Any

from .. import console
from ..adhoc import parse_adhoc_problem
from ..ai.deepseek import AIError, DeepSeekClient
from ..browser import AttachedBrowser, attach, ensure_chrome
from ..browser.launcher import ChromeHandle, is_cdp_ready, kill_chrome
from ..config import Config, ConfigError
from ..simulate import SimulationReport, Simulator
from ..solver import Solver, _problem_payload  # noqa: PLC2701 - 复用同一份题目摘要结构
from ..yuketang.constants import site_by_key
from .bus import EventBus

logger = logging.getLogger(__name__)


class ConsoleError(RuntimeError):
    """面向用户的操作失败，消息可直接展示在控制台上。"""


class ConsoleRuntime:
    """网页控制台的唯一状态持有者。"""

    def __init__(self, config: Config) -> None:
        self.config = config
        self.bus = EventBus()
        self.site = site_by_key(config.site)

        self._handle: ChromeHandle | None = None
        self._attached: AttachedBrowser | None = None
        self._client: DeepSeekClient | None = None
        self._solver: Solver | None = None
        self._watch_task: asyncio.Task[Any] | None = None
        self._last_report: SimulationReport | None = None
        self._browser_lock = asyncio.Lock()
        self._busy = False

    # -- 生命周期 ---------------------------------------------------------
    async def start(self) -> None:
        """进程启动时调用：有 Key 就先把模型客户端建好。"""
        if self.config.deepseek.api_key.strip():
            self._client = DeepSeekClient(self.config.deepseek)
            await self._client.__aenter__()
            self.bus.log(f"模型客户端已就绪：{self.config.deepseek.effective_model}")
        else:
            self.bus.log("未配置 DeepSeek API Key，模型相关功能不可用。", level="warn")

    async def close(self) -> None:
        await self.stop_watch()
        await self.detach_browser()
        if self._client is not None:
            await self._client.aclose()
            self._client = None

    # -- 浏览器 -----------------------------------------------------------
    async def ensure_browser(self) -> AttachedBrowser:
        """确保 Chrome 已启动并接管，返回可用的页面。"""
        if self._attached is not None:
            try:
                if not self._attached.page.is_closed():
                    return self._attached
            except Exception:  # pragma: no cover - 浏览器可能已被关掉
                pass
            await self.detach_browser()

        async with self._browser_lock:
            if self._attached is not None:
                return self._attached
            self.bus.log("正在启动 / 接管调试 Chrome…")
            try:
                self._handle = await ensure_chrome(
                    self.config.browser, self.config.user_data_path
                )
                attached = await attach(self._handle.cdp_url, self.site)
            except (ConfigError, RuntimeError) as exc:
                await self.detach_browser()
                raise ConsoleError(str(exc)) from exc
            self._attached = attached
            title = ""
            try:
                title = await attached.page.title()
            except Exception:  # pragma: no cover
                pass
            self.bus.publish(
                "browser",
                data={
                    "attached": True,
                    "url": attached.page.url,
                    "title": title,
                    "cdp_url": self._handle.cdp_url,
                },
            )
            self.bus.log(f"已接管页面：{attached.page.url}")
            return attached

    async def detach_browser(self) -> None:
        if self._attached is not None:
            await self._attached.close()
            self._attached = None
            self.bus.publish("browser", data={"attached": False})
        if self._handle is not None:
            if self._handle.launched:
                kill_chrome(self._handle)
            self._handle = None

    # -- 监听会话 ---------------------------------------------------------
    async def start_watch(
        self,
        *,
        mode: str | None = None,
        dry_run: bool | None = None,
        duration: float | None = None,
    ) -> dict[str, Any]:
        if self._watch_task is not None and not self._watch_task.done():
            raise ConsoleError("监听已经在运行中。")

        if self._client is None:
            raise ConsoleError(
                "未配置 DeepSeek API Key，无法启动监听。请在项目目录的 .env 里填写 "
                "DEEPSEEK_API_KEY 后重启控制台。"
            )

        # 配置问题（缺 Key、模式非法）应当是可控的 400，而不是 500
        try:
            config = self._with_overrides(mode=mode, dry_run=dry_run)
        except ConfigError as exc:
            raise ConsoleError(str(exc)) from exc

        attached = await self.ensure_browser()

        solver = Solver(
            config,
            attached.page,
            self.site,
            self._client,
            on_event=self.bus.publish,
        )
        self._solver = solver
        self._watch_task = asyncio.create_task(solver.run(duration=duration))
        # run() 是异步任务，必须等它真正挂上抓题器，否则紧接着的投喂会落空
        if not await solver.wait_ready(timeout=20):
            await self.stop_watch()
            raise ConsoleError("监听启动超时，请查看终端日志。")
        self.bus.log(
            f"监听已启动：模式={config.answer.mode}"
            f"{'（dry-run）' if config.answer.dry_run else ''}"
        )
        return self.state()

    async def stop_watch(self) -> dict[str, Any]:
        if self._solver is not None:
            self._solver.request_stop()
        if self._watch_task is not None:
            try:
                await asyncio.wait_for(asyncio.shield(self._watch_task), timeout=15)
            except (asyncio.TimeoutError, asyncio.CancelledError):
                self._watch_task.cancel()
            except Exception:  # pragma: no cover - 会话内部异常已记录
                logger.debug("监听任务结束时抛出异常", exc_info=True)
            self._watch_task = None
        self._solver = None
        return self.state()

    # -- 模拟检测 ---------------------------------------------------------
    async def simulate(self, kind: str) -> dict[str, Any]:
        if self._busy:
            raise ConsoleError("已有诊断任务在运行，请稍候。")
        self._busy = True
        self.bus.log(f"开始模拟检测：{kind}")
        try:
            simulator = Simulator(
                self.config, self.site, client=self._client, emit=self.bus.publish
            )
            if kind == "offline":
                report = await simulator.run_offline(test_model=self._client is not None)
            elif kind == "browser":
                attached = await self.ensure_browser()
                report = await simulator.run_browser(
                    attached.page, test_model=self._client is not None
                )
            elif kind == "live":
                capture = self._solver.capture if self._solver is not None else None
                if capture is None:
                    raise ConsoleError("请先启动监听，再执行端到端投喂检测。")
                report = await simulator.feed_live(capture)
            else:
                raise ConsoleError(f"未知的模拟类型：{kind}")
        finally:
            self._busy = False

        self._last_report = report
        payload = report.to_dict()
        self.bus.publish("simulation", data=payload)
        level = "info" if report.ok else "warn"
        summary = "全部通过" if report.ok else "存在未通过项"
        self.bus.log(f"模拟检测结束（{report.title}）：{summary}", level=level)
        return payload

    # -- 手动提问 ---------------------------------------------------------
    async def ask(self, text: str) -> dict[str, Any]:
        if self._client is None:
            raise ConsoleError("未配置 DeepSeek API Key。")
        problem = parse_adhoc_problem(text)
        if not problem.prompt and not problem.options:
            raise ConsoleError("没能从输入里解析出题目，请至少给出一行题干。")
        self.bus.publish("problem", data={"index": 0, "problem": _problem_payload(problem)})
        suggestion = await self._client.ask(problem)
        payload = {
            "problem_id": suggestion.problem_id,
            "display": suggestion.display(problem),
            "explanation": suggestion.explanation,
            "confidence": suggestion.confidence,
            "failure_reason": suggestion.failure_reason,
            "model": suggestion.model,
            "elapsed": round(suggestion.elapsed, 2),
            "payload": suggestion.submit_payload(problem),
        }
        self.bus.publish("answer", data={"problem_id": problem.id, "ok": suggestion.answerable, "suggestion": payload})
        return payload

    async def dump_page(self) -> dict[str, Any]:
        """导出当前页面结构，便于校准选择器。"""
        from ..solver import dump_current_page

        attached = await self.ensure_browser()
        path = await dump_current_page(attached.page, self.config)
        return {"path": str(path)}

    # -- 状态 -------------------------------------------------------------
    def state(self) -> dict[str, Any]:
        browser: dict[str, Any] = {"attached": False}
        if self._attached is not None:
            try:
                browser = {
                    "attached": not self._attached.page.is_closed(),
                    "url": self._attached.page.url,
                    "cdp_url": self._handle.cdp_url if self._handle else self.config.browser.cdp_url,
                }
            except Exception:  # pragma: no cover
                browser = {"attached": False}

        watching = self._watch_task is not None and not self._watch_task.done()
        stats = self._solver.stats.to_dict() if (watching and self._solver) else None
        capture_stats = None
        if watching and self._solver and self._solver.capture is not None:
            capture_stats = dict(self._solver.capture.stats)

        return {
            "site": {"key": self.site.key, "label": self.site.label, "host": self.site.host},
            "answer": {
                "mode": self.config.answer.mode,
                "dry_run": self.config.answer.dry_run,
                "min_confidence": self.config.answer.min_confidence,
            },
            "model": {
                "name": self.config.deepseek.effective_model,
                "base_url": self.config.deepseek.base_url,
                "configured": bool(self.config.deepseek.api_key.strip()),
                "vision": self.config.deepseek.vision_enabled,
            },
            "browser": browser,
            "watching": watching,
            "stats": stats,
            "capture_stats": capture_stats,
            "busy": self._busy,
            "last_simulation": self._last_report.to_dict() if self._last_report else None,
            "subscribers": self.bus.subscriber_count,
        }

    async def probe(self) -> dict[str, Any]:
        """自检：配置文件、API Key、调试端口。"""
        cdp_ready = await is_cdp_ready(self.config.browser.cdp_url)
        return {
            "config_path": str(self.config.config_path) if self.config.config_path else None,
            "project_root": str(self.config.project_root),
            "api_key_configured": bool(self.config.deepseek.api_key.strip()),
            "cdp_url": self.config.browser.cdp_url,
            "cdp_ready": cdp_ready,
            "auto_launch": self.config.browser.auto_launch,
            "chrome_found": bool(self.config.browser.chrome_path) or True,
            "record_dir": str(self.config.record_path),
        }

    # -- 内部 -------------------------------------------------------------
    def _with_overrides(self, *, mode: str | None, dry_run: bool | None) -> Config:
        answer = self.config.answer
        if mode is not None or dry_run is not None:
            answer = dataclasses.replace(
                answer,
                mode=mode if mode is not None else answer.mode,
                dry_run=dry_run if dry_run is not None else answer.dry_run,
            )
        config = dataclasses.replace(self.config, answer=answer)
        config.validate()
        return config


async def check_ai(config: Config) -> dict[str, Any]:
    """独立的自检入口，供 CLI 的 --check 与网页控制台共用。"""
    from ..models import Option, Problem, ProblemType

    test_problem = Problem(
        id="self-test",
        type=ProblemType.SINGLE_CHOICE,
        prompt="下列数字中哪一个是质数？",
        options=[Option(0, "4"), Option(1, "6"), Option(2, "7"), Option(3, "9")],
        source="check",
    )
    try:
        async with DeepSeekClient(config.deepseek) as client:
            suggestion = await client.ask(test_problem)
    except AIError as exc:
        return {"ok": False, "detail": str(exc)}
    return {
        "ok": suggestion.answerable,
        "detail": f"答案={suggestion.display(test_problem)}（参考 C. 7），耗时 {suggestion.elapsed:.1f}s",
    }


__all__ = ["ConsoleError", "ConsoleRuntime", "check_ai"]
