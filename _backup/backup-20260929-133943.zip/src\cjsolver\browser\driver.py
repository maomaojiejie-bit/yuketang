"""浏览器驱动：通过 CDP 接管 Chrome 并定位到雨课堂页面。"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any

from playwright.async_api import Browser, BrowserContext, Page, async_playwright

from ..console import info, warn
from ..yuketang.constants import Site, is_yuketang_host


@dataclass
class AttachedBrowser:
    """一份已连接的浏览器资源，由调用方负责关闭 Playwright。"""

    playwright: Any
    browser: Browser
    context: BrowserContext
    page: Page
    site: Site

    async def close(self) -> None:
        # CDP 接管模式下 browser.close() 会连带关掉用户的 Chrome，这里只断开连接
        try:
            await self.browser.close()
        except Exception:
            pass
        try:
            await self.playwright.stop()
        except Exception:
            pass


async def attach(cdp_url: str, site: Site) -> AttachedBrowser:
    """连接到调试 Chrome，并选出一个雨课堂页面（没有就新开一个）。"""
    playwright = await async_playwright().start()
    try:
        browser = await playwright.chromium.connect_over_cdp(cdp_url)
    except Exception as exc:
        await playwright.stop()
        raise RuntimeError(
            f"无法通过 CDP 连接 {cdp_url}：{exc}\n"
            "请确认 Chrome 是以 --remote-debugging-port 启动的，且端口未被防火墙拦截。"
        ) from exc

    contexts = browser.contexts
    context = contexts[0] if contexts else await browser.new_context()
    page = pick_page(context, site) or await open_site_page(context, site)
    return AttachedBrowser(playwright, browser, context, page, site)


def pick_page(context: BrowserContext, site: Site) -> Page | None:
    """优先选当前站点页面，其次任意雨课堂页面，最后任意普通页面。"""
    pages = [p for p in context.pages if not p.is_closed()]
    if not pages:
        return None

    exact = [p for p in pages if _host_of(p.url) == site.host]
    if exact:
        return exact[0]

    any_yuketang = [p for p in pages if is_yuketang_host(_host_of(p.url))]
    if any_yuketang:
        warn(
            f"当前打开的雨课堂页面属于 {_host_of(any_yuketang[0].url)}，"
            f"与配置站点 {site.host} 不一致，仍将使用该页面。"
        )
        return any_yuketang[0]

    ordinary = [p for p in pages if not p.url.startswith(("devtools://", "chrome://", "edge://"))]
    if ordinary:
        warn(f"没有找到雨课堂标签页，将复用当前标签页：{ordinary[0].url[:80]}")
        return ordinary[0]

    # 只剩 chrome://newtab 这类内部页面：返回 None 让调用方另开一个站点标签页
    return None


async def open_site_page(context: BrowserContext, site: Site) -> Page:
    """新开一个标签页并导航到站点首页。"""
    page = await context.new_page()
    info(f"打开新标签页：{site.start_url}")
    try:
        await page.goto(site.start_url, wait_until="domcontentloaded", timeout=45_000)
    except Exception as exc:
        warn(f"打开 {site.start_url} 失败（可稍后手动刷新）：{exc}")
    return page


def _host_of(url: str) -> str:
    from urllib.parse import urlparse

    try:
        return (urlparse(url).hostname or "").lower()
    except Exception:
        return ""


async def goto_lesson(page: Page, site: Site, lesson_id: str, classroom_id: str | None = None) -> None:
    """跳到进行中的课堂页面。"""
    if classroom_id:
        url = f"{site.origin}/lesson/fullscreen/v3/{lesson_id}/{classroom_id}"
    else:
        url = f"{site.origin}/lesson/fullscreen/v3/{lesson_id}"
    info(f"跳转课堂：{url}")
    await page.goto(url, wait_until="domcontentloaded", timeout=45_000)


async def fetch_on_lesson(page: Page, site: Site) -> list[dict[str, Any]]:
    """在页面上下文里查询当前正在进行的课堂，附带 Cookie 与鉴权头。"""
    script = """
    async (url) => {
      try {
        const response = await fetch(url, { credentials: 'include' });
        const text = await response.text();
        return { ok: response.ok, status: response.status, text };
      } catch (error) {
        return { ok: false, status: 0, text: String(error) };
      }
    }
    """
    result = await page.evaluate(script, site.api("/api/v3/classroom/on-lesson"))
    if not result or not result.get("ok"):
        return []
    import json

    try:
        payload = json.loads(result.get("text") or "{}")
    except json.JSONDecodeError:
        return []
    return parse_on_lesson(payload)


def parse_on_lesson(payload: Any) -> list[dict[str, Any]]:
    """解析 on-lesson 响应，兼容 data / result 包裹与多种字段命名。"""
    if not isinstance(payload, dict):
        return []
    root = payload.get("data") or payload.get("result") or payload
    if isinstance(root, list):
        raw = root
    elif isinstance(root, dict):
        raw = (
            root.get("onLessonClassrooms")
            or root.get("on_lesson_classrooms")
            or []
        )
    else:
        return []

    lessons: list[dict[str, Any]] = []
    for item in raw:
        if not isinstance(item, dict):
            continue
        lesson_id = item.get("lessonId") or item.get("lesson_id") or item.get("id")
        if lesson_id is None:
            continue
        lessons.append(
            {
                "id": str(lesson_id),
                "title": str(
                    item.get("title")
                    or item.get("lessonName")
                    or item.get("lesson_name")
                    or item.get("name")
                    or ""
                ),
                "classroom_id": _str_or_none(
                    item.get("classroomId") or item.get("classroom_id")
                ),
                "presentation_id": _str_or_none(
                    item.get("presentationId") or item.get("presentation_id")
                ),
            }
        )
    return lessons


def _str_or_none(value: Any) -> str | None:
    if value is None or isinstance(value, bool):
        return None
    return str(value)
